/*
 * LOPEZ, LUIS ENRICO D.
 * RIVERA, LOUIE IV Y.
 * SWDESPA S17
 */

public class Driver {
	public static void main(String[] args) {
		AdminMenu am = new AdminMenu(new TrafficSubject("Metro Cebu"));
		am.start();
	}
}
